
"use strict";

let GoalCount = require('./GoalCount.js')

module.exports = {
  GoalCount: GoalCount,
};
