.. assignment_2_2022 documentation master file, created by
   sphinx-quickstart on Sun May  7 12:08:17 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to assignment_2_2022's documentation!
=============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

Assignment_2_2022 documentation!
*********************************

This is the documentation of the assignment_2_2022 package!


Client Module
==============

.. automodule:: scripts.client
   :members:
   
   
Publisher Module
=================

.. automodule:: scripts.publisher
   :members:
   
   
Subscriber Module
==================

.. automodule:: scripts.subscriber
   :members:

Goal Tracker Module
===================

.. automodule:: scripts.goalTracker
   :members:


